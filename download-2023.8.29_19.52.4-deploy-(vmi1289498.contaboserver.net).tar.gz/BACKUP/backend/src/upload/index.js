const express = require("express");
const uploadRouter = require("./routes/upload");
const buildRouter = require("./routes/build");

const app = express();

app.use("/upload", uploadRouter);
app.use("/build", buildRouter);

// Outras configurações e middleware do seu aplicativo...

app.listen(3000, () => {
  console.log("Servidor rodando na porta 3000");
});
